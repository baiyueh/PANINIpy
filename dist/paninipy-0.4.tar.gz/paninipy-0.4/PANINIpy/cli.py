def main():
    print("Package loading!")